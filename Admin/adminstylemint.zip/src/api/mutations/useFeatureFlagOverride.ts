import { useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '@/api/client'
import { qk } from '@/api/queryKeys'

type SetOverrideVars = {
  key: string
  roleKind?: 'Customer' | 'Creator' | 'Vendor'
  accountId?: string
  enabled: boolean
}

export function useFeatureFlagOverride(options?: { onSuccess?: () => void; onError?: (e: unknown) => void }) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (vars: SetOverrideVars) => {
      const { key, ...body } = vars
      const { data } = await api.put(`/v1/admin/feature-flags/${key}/overrides`, body)
      return data
    },
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: qk.flag(vars.key) })
      options?.onSuccess?.()
    },
    onError: options?.onError,
  })
}
